"""Add four verified main skills and four complete evolution families (v162)."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MASTER = ROOT / "master"

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")

skills = {
    "energy_charge_m": ("エナジーチャージM", "fixed_energy", [880,1251,1726,2383,3290,4546,6858], "energy", "カビゴンのエナジーを{n}増やす", ["エナジー","固定"]),
    "energy_charge_s_self": ("げんきチャージS", "self_energy_recovery", [12,16,21,26,33,43], "recovery", "自分のげんきを{n}回復する", ["げんき","自分"]),
    "energy_cheer_s": ("げんきエールS", "ally_energy_recovery", [12,15,20,25,33,44], "recovery", "チームのポケモン1匹のげんきを{n}回復する", ["げんき","ランダム"]),
    "extra_helpful_s": ("おてつだいサポートS", "extra_help", [6,7,8,9,10,11,12], "helps", "チームのポケモン1匹のおてつだい{n}回分がすぐに完了する", ["おてつだい","サポート"]),
}
for key,(name,effect,values,value_key,template,tags) in skills.items():
    write(MASTER/"skills"/key/"data.json", {
        "id":key,"name":name,"maxLevel":len(values),"tags":tags,"effectType":effect,
        "levels":{str(i):{value_key:n,"description":template.format(n=n)} for i,n in enumerate(values,1)}
    })

ingredients = {
    "tasty_tail": ("おいしいシッポ","🍖"),
    "large_leek": ("ふといながねぎ","🥬"),
}
for key,(name,fallback) in ingredients.items():
    write(MASTER/"ingredients"/key/"data.json",{"id":key,"name":name,"fallback":fallback})

# no, name, type, sleep type, specialty, berry, help, carry, food%, skill%,
# skill ID, A/B/C ingredient options and quantities, four sleep-style names.
families = [
 (69,"マダツボミ","くさ","うとうと","食材","ドリのみ",5200,8,23.3,3.9,"energy_charge_s_self",
  [[("tomato",2)],[("tomato",5),("potato",4)],[("tomato",7),("potato",6),("large_leek",4)]],
  ["あしのばし寝","ようかいえき寝","ねをはる寝","おなかのうえ寝"]),
 (70,"ウツドン","くさ","うとうと","食材","ドリのみ",3800,17,23.5,4.0,"energy_charge_s_self",
  [[("tomato",2)],[("tomato",5),("potato",4)],[("tomato",7),("potato",6),("large_leek",4)]],
  ["ようかいえき寝","ふゆう寝","くっつき寝","おなかのうえ寝"]),
 (71,"ウツボット","くさ","うとうと","食材","ドリのみ",2800,27,23.3,3.9,"energy_charge_s_self",
  [[("tomato",2)],[("tomato",5),("potato",4)],[("tomato",7),("potato",6),("large_leek",4)]],
  ["ばふばふ寝","つるささえ寝","ひっくりかえり寝","おなかのうえ寝"]),
 (79,"ヤドン","みず","すやすや","スキル","オレンのみ",5700,9,15.1,7.8,"energy_cheer_s",
  [[("soothing_cacao",1)],[("soothing_cacao",2),("tasty_tail",1)],[("soothing_cacao",4),("tasty_tail",2),("tomato",5)]],
  ["ぐでぐで寝","ぼーっと寝","まぬけだ寝","おなかのうえ寝"]),
 (80,"ヤドラン","みず","すやすや","スキル","オレンのみ",3800,21,19.7,8.0,"energy_cheer_s",
  [[("soothing_cacao",1)],[("soothing_cacao",2),("tasty_tail",1)],[("soothing_cacao",4),("tasty_tail",2),("tomato",5)]],
  ["なかよし寝","よだれ寝","しっぽかまれ寝","おなかのうえ寝"]),
 (199,"ヤドキング","みず","すやすや","スキル","オレンのみ",3400,22,16.6,8.7,"energy_cheer_s",
  [[("soothing_cacao",1)],[("soothing_cacao",2),("tasty_tail",1)],[("soothing_cacao",4),("tasty_tail",2),("tomato",5)]],
  ["ぐうたら寝","けんじゃ寝","ひらめき寝","おなかのうえ寝"]),
 (179,"メリープ","でんき","すやすや","スキル","ウブのみ",4600,9,12.8,4.7,"energy_charge_m",
  [[("fiery_herb",1)],[("fiery_herb",2),("fancy_egg",3)],[("fiery_herb",4),("fancy_egg",4)]],
  ["もこもこ寝","ひづめかき寝","しっぽひかり寝","おなかのうえ寝"]),
 (180,"モココ","でんき","すやすや","スキル","ウブのみ",3300,16,12.7,4.6,"energy_charge_m",
  [[("fiery_herb",1)],[("fiery_herb",2),("fancy_egg",3)],[("fiery_herb",4),("fancy_egg",4)]],
  ["ぺったり寝","もこもこ寝","しっぽひかり寝","おなかのうえ寝"]),
 (181,"デンリュウ","でんき","すやすや","スキル","ウブのみ",2500,25,13.0,4.7,"energy_charge_m",
  [[("fiery_herb",1)],[("fiery_herb",2),("fancy_egg",3)],[("fiery_herb",4),("fancy_egg",4)]],
  ["しっぽかき寝","くびふり寝","しっぽかがやき寝","おなかのうえ寝"]),
 (58,"ガーディ","ほのお","すやすや","スキル","ヒメリのみ",4300,8,13.8,5.0,"extra_helpful_s",
  [[("fiery_herb",1)],[("fiery_herb",2),("bean_meat",3)],[("fiery_herb",4),("bean_meat",5),("moomoo_milk",5)]],
  ["のび寝","おすわり寝","へそてん寝","おなかのうえ寝"]),
 (59,"ウインディ","ほのお","すやすや","スキル","ヒメリのみ",2500,21,13.6,4.9,"extra_helpful_s",
  [[("fiery_herb",1)],[("fiery_herb",2),("bean_meat",3)],[("fiery_herb",4),("bean_meat",5),("moomoo_milk",5)]],
  ["ふせ寝","おすわり寝","へそてん寝","おなかのうえ寝"]),
]
evolutions={
 69:{"toNo":70,"to":"ウツドン","level":16,"candy":40},
 70:{"toNo":71,"to":"ウツボット","item":"リーフのいし","candy":80},
 79:[{"toNo":80,"to":"ヤドラン","level":28,"candy":40},{"toNo":199,"to":"ヤドキング","item":"おうじゃのしるし","extra":"つながりのヒモ","candy":80}],
 179:{"toNo":180,"to":"モココ","level":11,"candy":40},
 180:{"toNo":181,"to":"デンリュウ","level":23,"candy":80},
 58:{"toNo":59,"to":"ウインディ","item":"ほのおのいし","candy":80},
}
for no,name,ptype,sleep,specialty,berry,help_time,carry,food_rate,skill_rate,skill,slots,styles in families:
    record={"no":no,"name":name,"type":ptype,"sleepType":sleep,"specialty":specialty,
        "berry":berry,"berryQty":1,"help":help_time,"carry":carry,
        "foodRate":food_rate,"skillRate":skill_rate,"rateStatus":"推定",
        "mainSkillId":skill,"dexVisible":True,"ingredientSlotStatus":"verified",
        "ingredientSlots":[{"unlock":unlock,"candidates":[{"ingredientId":key,"qty":qty} for key,qty in row]} for unlock,row in zip((1,30,60),slots)],
        "sleepStyles":[{"id":f"{no:04d}_{i:02d}","name":label,"stars":i} for i,label in enumerate(styles,1)]}
    if no in evolutions: record["evolution"]=evolutions[no]
    write(MASTER/"pokemon"/f"{no:04d}"/"data.json",record)

# Normal-mode encounters only. Each tuple: species, star, tier, level, DPR.
encounters={
 "greengrass":[
  (69,1,"ノーマル",1,76000),(69,2,"ノーマル",5,1824000),(69,4,"スーパー",1,9918000),
  (70,1,"スーパー",2,1824000),(70,2,"ハイパー",1,5054000),(70,4,"ハイパー",2,20824000),
  (71,1,"マスター",2,9918000),(71,2,"マスター",6,20824000),(71,4,"マスター",7,59052000),
  (79,1,"ノーマル",2,76000),(79,2,"スーパー",1,2090000),(79,4,"ハイパー",1,10830000),
  (80,1,"ハイパー",1,3154000),(80,2,"ハイパー",5,7714000),(80,4,"マスター",1,28766000),
  (179,1,"ノーマル",1,76000),(179,2,"ノーマル",5,1558000),(179,4,"スーパー",1,9120000),
  (180,1,"スーパー",2,1824000),(180,2,"ハイパー",1,5054000),(180,4,"ハイパー",2,20824000),
  (58,1,"ノーマル",2,76000),(58,2,"スーパー",1,2280000),(58,4,"スーパー",2,11780000)],
 "cyan":[
  (69,1,"ノーマル",1,76000),(69,2,"ノーマル",2,1824000),(69,3,"スーパー",3,7144000),(69,4,"スーパー",1,9918000),
  (79,1,"ノーマル",1,76000),(79,2,"ノーマル",3,2090000),(79,3,"スーパー",4,7714000),(79,4,"ハイパー",1,10830000),
  (80,1,"スーパー",3,3154000),(80,2,"ハイパー",2,7714000),(80,3,"マスター",3,22154000),(80,4,"ハイパー",3,28766000),
  (199,1,"マスター",2,16644000),(199,2,"マスター",6,31806000),(199,3,"マスター",12,68666000),(199,4,"マスター",7,85614000)],
 "taupe":[
  (58,1,"ノーマル",1,76000),(58,2,"ノーマル",2,2280000),(58,3,"スーパー",3,8322000),(58,4,"スーパー",1,11780000),
  (59,1,"マスター",2,16644000),(59,2,"マスター",6,31806000),(59,3,"マスター",12,68666000),(59,4,"マスター",7,85614000)],
 "snowdrop":[
  (179,1,"ノーマル",1,76000),(179,2,"ノーマル",1,1558000),(179,3,"スーパー",1,6574000),(179,4,"スーパー",1,9120000),
  (180,1,"ノーマル",2,1824000),(180,2,"スーパー",1,5054000),(180,3,"ハイパー",2,15466000),(180,4,"スーパー",2,20824000),
  (181,1,"ハイパー",2,9918000),(181,2,"マスター",1,20824000),(181,3,"マスター",7,48070000),(181,4,"マスター",2,59052000)]
}
for field_id, rows in encounters.items():
    path=MASTER/"fields"/field_id/"data.json"
    field=json.loads(path.read_text())
    known={entry["sleepStyleId"] for entry in field.setdefault("encounters",[])}
    for no,star,tier,level,dpr in rows:
        style_id=f"{no:04d}_{star:02d}"
        if style_id in known: continue
        field["encounters"].append({"sleepStyleId":style_id,"rank":{"tier":tier,"level":level},"drowsyPower":dpr})
        known.add(style_id)
    write(path,field)

print(f"Added {len(skills)} skills, {len(families)} Pokémon, {sum(map(len,encounters.values()))} normal field encounters")

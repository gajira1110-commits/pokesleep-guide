"""Validate master folders and produce the single-file GitHub Pages review."""
import base64
import json
import mimetypes
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MASTER = ROOT / 'master'
TEMPLATE = ROOT / 'PSG_source_template.html'
CSS = ROOT / 'PSG_styles.css'
ART = ROOT / 'PSG_specialty_images.js'
FACE_SHEET = ROOT / 'assets/faces/kanto_vol1_sheet.png'
PREVIEW = ROOT / 'review.html'
SNAPSHOT = ROOT / 'PSG_v165_master_review.html'
MARKER = '/* PSG_BUILD_CATALOG */'


def records(kind):
    folder = MASTER / kind
    result = {}
    for path in sorted(folder.glob('*/data.json')):
        obj = json.loads(path.read_text())
        key = str(obj['no']) if kind == 'pokemon' else obj['id']
        assert path.parent.name == (f'{int(key):04d}' if kind == 'pokemon' else key), path
        assert key not in result, f'duplicate {kind} id: {key}'
        result[key] = (obj, path.parent)
    return result


def inline_image(folder, basename):
    found = [p for p in folder.glob(f'{basename}.*') if p.suffix.lower() in ('.webp', '.png', '.jpg', '.jpeg')]
    assert len(found) <= 1, f'ambiguous image: {folder}/{basename}'
    if not found:
        return None
    image = found[0]
    mime = mimetypes.guess_type(image.name)[0]
    return f'data:{mime};base64,{base64.b64encode(image.read_bytes()).decode()}'


def catalog_and_images():
    data = json.loads((MASTER / 'catalog.json').read_text())
    natures = json.loads((MASTER / 'natures' / 'data.json').read_text())
    subskills = json.loads((MASTER / 'subskills' / 'data.json').read_text())
    axes = natures['axes']
    assert len(axes) == 5 and len(set(axes)) == 5
    assert set(natures['factors']) == set(axes)
    for factors in natures['factors'].values():
        assert 0 < factors['up'] <= 2 and 0 < factors['down'] <= 2
    rows = natures['rows']
    assert len(rows) == len(axes) and all(len(row) == len(axes) for row in rows)
    nature_names = [name for row in rows for name in row]
    assert len(set(nature_names)) == 25 and all(nature_names)
    allowed_effects = {'berryQtyBonus','teamSpeedReduction','speedReduction','foodRateBonus','skillRateBonus','carryBonus','skillLevelBonus','sleepEnergyBonus','sleepExpBonus','dreamShardBonus','researchExpBonus'}
    skill_names = [item['name'] for item in subskills['records']]
    assert len(set(skill_names)) == len(skill_names) and all(skill_names)
    for item in subskills['records']:
        assert item['effect'] in allowed_effects
        assert isinstance(item['value'],(int,float)) and item['value'] > 0
    kinds = {kind:records(kind) for kind in ('pokemon','ingredients','berries','skills','recipes','fields')}
    ingredients = kinds['ingredients']
    assert kinds['pokemon'], 'empty pokemon master'
    by_name = {obj['name']:key for key,(obj,_) in ingredients.items()}
    assert len(by_name) == len(ingredients), 'duplicate ingredient name'
    images = {key:{} for key in ('pokemon','pokemonFaces','ingredients','berries','skills','recipes','sleepStyles','fields','subskills')}
    catalog = {**data,'pokemon':{},'sleepStyles':{},'recipes':{},'skills':{},'ingredientAssets':{},'berries':{},'fields':{},
               'natures':natures,'subskills':subskills['records']}
    badges = json.loads((ROOT / 'assets/subskills/manifest.json').read_text())
    assert set(badges) == set(skill_names), 'subskill badge manifest must cover all master records'
    for name,filename in badges.items():
        svg = (ROOT / 'assets/subskills' / filename).read_bytes()
        images['subskills'][name] = 'data:image/svg+xml;base64,' + base64.b64encode(svg).decode()
    for key,(field,folder) in kinds['fields'].items():
        assert field['id'] == key and field.get('name') and field.get('mode') == 'normal'
        assert field.get('favoriteMode') in ('fixed','weekly_random'), key
        favorites = field.get('favoriteBerries')
        assert isinstance(favorites,list) and len(favorites) == (3 if field['favoriteMode'] == 'fixed' else 0), key
        assert all(isinstance(name,str) and name for name in favorites) and len(set(favorites)) == len(favorites), key
        ranks = field.get('rankThresholds')
        assert isinstance(ranks,list) and len(ranks) == 35, f'{key}: expected Normal/Great/Ultra 1-5 and Master 1-20'
        expected_ranks = [(tier,level) for tier,limit in (('ノーマル',5),('スーパー',5),('ハイパー',5),('マスター',20)) for level in range(1,limit+1)]
        assert [(rank.get('tier'),rank.get('level')) for rank in ranks] == expected_ranks, f'{key}: invalid rank order'
        assert ranks[0]['energy'] == 0 and all(isinstance(rank['energy'],int) and rank['energy'] > ranks[i-1]['energy'] for i,rank in enumerate(ranks) if i), f'{key}: invalid energy thresholds'
        catalog['fields'][key] = field
        image = inline_image(folder,'image')
        if image:
            images['fields'][key] = image
    for key,(berry,folder) in kinds['berries'].items():
        assert berry['id'] == key and berry.get('name') and isinstance(berry.get('baseEnergy'),int) and berry['baseEnergy'] > 0
        assert berry['name'] not in catalog['berries'], f'duplicate berry name: {berry["name"]}'
        catalog['berries'][berry['name']] = berry['baseEnergy']
    catalog['berryNames'] = sorted(set(catalog['berries']) | {name for field in catalog['fields'].values() for name in field['favoriteBerries']})
    for key,(obj,folder) in ingredients.items():
        assert obj['id'] == key and obj['name']
        catalog['ingredientAssets'][obj['name']] = {field:value for field,value in obj.items() if field not in ('id','name')}
        icon = inline_image(folder, 'icon')
        if icon:
            images['ingredients'][obj['name']] = icon
    for key,(obj,folder) in kinds['skills'].items():
        assert obj['id'] == key and obj.get('levels')
        if obj.get('effectType') == 'variable_energy':
            assert sorted(map(int,obj['levels'])) == list(range(1,obj['maxLevel']+1)), key
            assert all(isinstance(level.get('min'),int) and isinstance(level.get('max'),int) and 0 < level['min'] <= level['max'] for level in obj['levels'].values()), key
        catalog['skills'][key] = obj
        icon = inline_image(folder, 'icon')
        if icon:
            images['skills'][key] = icon
    for key,(obj,folder) in kinds['pokemon'].items():
        assert obj['no'] == int(key) and obj.get('name') and obj.get('mainSkillId') in catalog['skills']
        assert obj.get('type') and obj.get('sleepType') and obj.get('specialty')
        assert obj.get('berry') in catalog['berries'], f'{key}: unknown berry {obj.get("berry")}'
        for field in ('help','carry','berryQty'):
            if field in obj:
                assert isinstance(obj[field],(int,float)) and obj[field] > 0, f'{key}: invalid {field}'
        for field in ('foodRate','skillRate'):
            if field in obj:
                assert isinstance(obj[field],(int,float)) and 0 <= obj[field] <= 100, f'{key}: invalid {field}'
        if 'foodRate' in obj or 'skillRate' in obj:
            assert obj.get('rateStatus') in ('推定','確認済み'), f'{key}: missing rateStatus'
        obj = obj.copy()
        styles = obj.pop('sleepStyles', [])
        seen_styles = set()
        for style in styles:
            assert style['id'].startswith(f'{int(key):04d}_') and style['id'] not in seen_styles
            assert style['name'] and 1 <= style['stars'] <= 5
            seen_styles.add(style['id'])
            photo = inline_image(folder / 'sleep', style['id'])
            if photo:
                images['sleepStyles'][style['id']] = photo
        catalog['sleepStyles'][key] = [[style['name'],style['stars'],style['id']] for style in styles]
        for slot in obj.get('ingredientSlots', []):
            assert slot['unlock'] in (1,30,60) and slot.get('candidates')
            for candidate in slot['candidates']:
                ingredient_id = candidate.pop('ingredientId')
                assert ingredient_id in ingredients, f'{key}: unknown ingredient {ingredient_id}'
                assert isinstance(candidate.get('qty'),int) and candidate['qty'] > 0
                candidate['name'] = ingredients[ingredient_id][0]['name']
        catalog['pokemon'][key] = obj
        for role, asset_key in (('face','pokemonFaces'),('full','pokemon')):
            image = inline_image(folder,role)
            if image:
                images[asset_key][key] = image
    style_index = {style[2]:(no,style) for no,styles in catalog['sleepStyles'].items() for style in styles}
    tiers = {'ノーマル','スーパー','ハイパー','マスター'}
    drowsy_by_style = {}
    for field_id,field in catalog['fields'].items():
        seen = set()
        for encounter in field.get('encounters',[]):
            style_id = encounter['sleepStyleId']
            assert style_id in style_index and style_id not in seen, f'{field_id}: invalid/duplicate style {style_id}'
            seen.add(style_id)
            rank = encounter['rank']
            assert rank['tier'] in tiers and isinstance(rank['level'],int) and rank['level'] >= 1, field_id
            assert isinstance(encounter['drowsyPower'],int) and encounter['drowsyPower'] > 0, field_id
            assert drowsy_by_style.setdefault(style_id,encounter['drowsyPower']) == encounter['drowsyPower'], f'{style_id}: inconsistent DPR'
    for key,(recipe,folder) in kinds['recipes'].items():
        assert key == recipe['id'] and recipe['name'] and recipe.get('ingredients')
        assert recipe.get('category') in ('カレー・シチュー','サラダ','デザート・ドリンク'), key
        assert recipe.get('energy',{}).get('min',{}).get('level') == 1, key
        assert recipe.get('energy',{}).get('max',{}).get('level') == 70, key
        assert 0 < recipe['energy']['min']['value'] <= recipe['energy']['max']['value'], key
        seen_ingredients = set()
        for ingredient in recipe['ingredients']:
            ingredient_id = ingredient.pop('ingredientId')
            assert ingredient_id in ingredients, f'{key}: unknown ingredient {ingredient_id}'
            assert ingredient_id not in seen_ingredients, f'{key}: duplicate ingredient {ingredient_id}'
            seen_ingredients.add(ingredient_id)
            assert isinstance(ingredient.get('qty'),int) and ingredient['qty'] > 0
            ingredient['name'] = ingredients[ingredient_id][0]['name']
        catalog['recipes'][key] = recipe
        image = inline_image(folder,'image')
        if image:
            images['recipes'][key] = image
    # The old catalog entries may contain pending numbers. New records are authoritative.
    catalog['pendingNationalNos'] = [n for n in data.get('pendingNationalNos',[]) if str(n) not in catalog['pokemon']]
    return catalog, images


def build():
    catalog, images = catalog_and_images()
    core = ('help','carry','berryQty','foodRate','skillRate','ingredientSlots')
    missing = [(f'{int(no):04d} {obj["name"]}',[field for field in core if field not in obj])
               for no,obj in catalog['pokemon'].items()]
    missing = [(name,fields) for name,fields in missing if fields]
    for name,fields in missing:
        print(f'Forecast data pending: {name}: {", ".join(fields)}')
    print(f'Forecast core fields: {len(catalog["pokemon"])-len(missing)}/{len(catalog["pokemon"])} species complete')
    source = TEMPLATE.read_text()
    assert source.count(MARKER) == source.count('/* PSG_BUILD_STYLES */') == source.count('/* PSG_BUILD_SPECIALTY_IMAGES */') == source.count('/* PSG_BUILD_FACE_SHEET */') == 1
    assert source.count('Review v165') == 2
    js_data = json.dumps(catalog,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
    js_images = json.dumps(images,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
    injection = ('window.PS_CATALOG='+js_data+';\n'
                 'for(const [kind,entries] of Object.entries('+js_images+'))'
                 'Object.assign(window.PS_IMAGE_FILES[kind],entries);')
    sheet_uri = 'data:image/png;base64,' + base64.b64encode(FACE_SHEET.read_bytes()).decode()
    html = source.replace(MARKER,injection).replace('/* PSG_BUILD_STYLES */',CSS.read_text()).replace('/* PSG_BUILD_SPECIALTY_IMAGES */',ART.read_text()).replace('/* PSG_BUILD_FACE_SHEET */',json.dumps(sheet_uri))
    assert MARKER not in html
    PREVIEW.write_text(html)
    SNAPSHOT.write_text(html)
    print(f'{len(catalog["pokemon"])} pokemon, {len(catalog["sleepStyles"])} sleep groups, '
          f'{len(catalog["recipes"])} recipes: {len(html)} characters')


if __name__ == '__main__':
    build()

// Rebuild the 17 provisional subskill badges from the approved visual sheet.
import fs from 'node:fs';
import path from 'node:path';

const out = path.resolve('assets/subskills');
fs.mkdirSync(out, {recursive:true});
const P = {
 berry:`<path d="M30 16q2-10 11-9M33 16q-8-10-15-7 3 9 13 10" fill="#64b944" stroke="#276022"/><circle cx="22" cy="29" r="7"/><circle cx="35" cy="26" r="7"/><circle cx="27" cy="41" r="7"/><circle cx="40" cy="40" r="7"/>`,
 speed:`<circle cx="34" cy="32" r="15" fill="none" stroke="currentColor" stroke-width="4"/><path d="M30 10h8M34 32l7-7M10 21h12M7 31h12M10 41h12" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><path d="m45 41 7-2-7 8z"/>`,
 teamwork:`<circle cx="34" cy="34" r="15" fill="#fff" stroke="currentColor" stroke-width="4"/><path d="M31 12h7m-4 0v7m0 15 6-6M10 27h10M8 37h10M47 11l2 5 5 2-5 2-2 5-2-5-5-2 5-2zM14 14l2 3 3 1-3 1-2 3-2-3-3-1 3-1z" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>`,
 basket:`<path d="M33 20q-1-9 5-12M34 20q8-11 17-8-1 10-17 11" fill="#75c849" stroke="#2b7239"/><path d="M31 21q-14-8-19 4-4 12 7 26 7 7 15 3 8 4 15-3 11-14 7-26-5-12-22-4z" fill="#ed4d3f" stroke="currentColor" stroke-width="3"/><path d="M19 30q1-5 7-6" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round"/>`,
 skill:`<path d="m32 10 6 14 15 2-11 10 3 16-13-8-13 8 3-16-11-10 15-2z" fill="none" stroke="currentColor" stroke-width="4" stroke-linejoin="round"/><circle cx="32" cy="33" r="6"/>`,
 pack:`<rect x="15" y="23" width="34" height="31" rx="6" fill="none" stroke="currentColor" stroke-width="4"/><path d="M24 23v-7a8 8 0 0 1 16 0v7M15 38h34M27 38v6h10v-6" fill="none" stroke="currentColor" stroke-width="4"/>`,
 moon:`<path d="M38 12a21 21 0 1 0 14 32A20 20 0 0 1 38 12z"/><path d="m44 14 2 4 5 1-5 2-2 5-2-5-5-2 5-1z"/><text x="30" y="42" fill="currentColor" stroke="none" font-family="system-ui,sans-serif" font-size="17" font-weight="900">Z</text>`,
 research:`<circle cx="28" cy="28" r="14" fill="none" stroke="currentColor" stroke-width="5"/><path d="m39 39 13 13M29 18l2 6 6 2-6 2-2 6-2-6-6-2 6-2z" fill="none" stroke="currentColor" stroke-width="4"/>`,
 shard:`<path d="M32 8 46 22 40 48 31 56 18 43 21 22z"/><path d="M21 22h25M32 8l-3 32 11 8M21 22l8 18-11 3" fill="none" stroke="currentColor" stroke-width="2"/>`,
 heart:`<path d="M32 53 13 35q-10-11-1-20 9-9 20 2 11-11 20-2 9 9-1 20z"/><path d="M32 22v18m-9-9h18" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round"/>`,
 level:`<path d="m32 12 5 13 13 5-13 5-5 13-5-13-13-5 13-5z" fill="#fff" stroke="currentColor" stroke-width="3"/><path d="m32 47 8 9H24z"/><path d="m32 49 8 9H24z" transform="translate(0 -8)" opacity=".5"/>`,
 trigger:`<path d="m32 12 5 13 13 5-13 5-5 13-5-13-13-5 13-5z" fill="#fff" stroke="currentColor" stroke-width="3"/><path d="M13 18q-13 13 0 26M51 18q13 13 0 26" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round"/>`,
 cap:`<path d="M15 49V23h18M25 34l17-18M33 16h9v9" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><path d="m47 35 2 5 5 2-5 2-2 5-2-5-5-2 5-2z"/>`,
};
const badges = [
 ['berry_count_s','きのみの数S','berry','gold','S'],
 ['helping_bonus','おてつだいボーナス','teamwork','gold',''],
 ['helping_speed_s','おてつだいスピードS','speed','silver','S'],
 ['helping_speed_m','おてつだいスピードM','speed','blue','M'],
 ['ingredient_s','食材確率アップS','basket','silver','S'],
 ['ingredient_m','食材確率アップM','basket','blue','M'],
 ['skill_trigger_s','スキル確率アップS','trigger','silver','S'],
 ['skill_trigger_m','スキル確率アップM','trigger','blue','M'],
 ['inventory_s','最大所持数アップS','pack','silver','S'],
 ['inventory_m','最大所持数アップM','pack','blue','M'],
 ['inventory_l','最大所持数アップL','pack','gold','L'],
 ['skill_level_s','スキルレベルアップS','level','silver','S'],
 ['skill_level_m','スキルレベルアップM','level','blue','M'],
 ['energy_recovery','げんき回復ボーナス','heart','gold',''],
 ['sleep_exp','睡眠EXPボーナス','moon','gold',''],
 ['dream_shard','ゆめのかけらボーナス','shard','gold',''],
 ['research_exp','リサーチEXPボーナス','research','gold',''],
];
const metal = {
 gold:['#fff0aa','#e7a939','#fff9d4','#764712','#6d420f'],
 blue:['#caf1ff','#419cda','#e9faff','#154c80','#154c80'],
 silver:['#fff','#aeb7c0','#f4f7f8','#59646d','#59646d']
};
function badge([id,name,icon,grade,letter],x=0,y=0){
 const [light,base,inner,edge,ink]=metal[grade];
 return `<g transform="translate(${x} ${y})"><title>${name}</title><circle cx="40" cy="40" r="32" fill="${base}" stroke="${edge}" stroke-width="2"/><circle cx="40" cy="40" r="27" fill="${light}" stroke="${inner}" stroke-width="3"/><circle cx="40" cy="40" r="22" fill="${inner}" opacity=".85"/><g transform="translate(11 11) scale(.9)" fill="${base}" stroke="${ink}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" style="color:${ink}">${P[icon]}</g>${letter?`<circle cx="61" cy="61" r="12" fill="${base}" stroke="${edge}" stroke-width="2"/><text x="61" y="67" text-anchor="middle" font-size="17" font-family="system-ui,sans-serif" font-weight="900" fill="${ink}">${letter}</text>`:''}</g>`;
}
const svg=(name,body,viewBox)=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${viewBox}" role="img" aria-label="${name}">${body}</svg>\n`;
for(const entry of badges)fs.writeFileSync(path.join(out,entry[0]+'.svg'),svg(entry[1],badge(entry),'0 0 80 80'));
const sheet=badges.map((entry,i)=>badge(entry,(i%6)*80,Math.floor(i/6)*80)).join('');
fs.writeFileSync(path.join(out,'subskill_badges_sheet.svg'),svg('サブスキルバッジ17種類',sheet,'0 0 480 240'));
const labeled=badges.map((entry,i)=>{const x=(i%6)*150,y=Math.floor(i/6)*115;return `<g transform="translate(${x} ${y})">${badge(entry,35,2)}<text x="75" y="106" text-anchor="middle" fill="#25312d" font-size="12" font-family="system-ui,sans-serif" font-weight="700">${entry[1]}</text></g>`}).join('');
fs.writeFileSync(path.join(out,'subskill_badges_labeled.svg'),svg('サブスキルバッジ17種類と名称',labeled,'0 0 900 345'));
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(Object.fromEntries(badges.map(([id,name])=>[name,`${id}.svg`])),null,2)+'\n');
console.log(`${badges.length} badges generated in ${out}`);
